# 🤖 Crypto Alert Bot - Telegram

Bot Telegram cảnh báo giá cryptocurrency real-time. Kiếm tiền tự động với affiliate marketing.

## ✨ Tính Năng

- ✅ Xem giá crypto real-time (100+ coins)
- ✅ Cảnh báo giá tự động 24/7
- ✅ Thông tin airdrop mới nhất
- ✅ Top trending coins
- ✅ Tích hợp affiliate links sẵn
- ✅ Database SQLite lưu alerts
- ✅ Background task tự động

## 📋 Yêu Cầu

- Python 3.8 trở lên
- Telegram Bot Token (lấy từ @BotFather)
- Internet connection

## 🚀 Cài Đặt

### Bước 1: Cài đặt Python

Tải Python tại: https://www.python.org/downloads/

Kiểm tra:
```bash
python --version
```

### Bước 2: Cài đặt thư viện

```bash
pip install -r requirements.txt
```

### Bước 3: Tạo Telegram Bot

1. Mở Telegram, tìm @BotFather
2. Gõ `/newbot`
3. Đặt tên bot (VD: My Crypto Alert Bot)
4. Đặt username bot (VD: MyCryptoAlertBot)
5. Copy **Bot Token** (dạng: 1234567890:ABCdefGHIjklMNOpqrsTUVwxyz)

### Bước 4: Cấu hình Bot

Mở file `bot.py`, tìm dòng:

```python
BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"
```

Thay bằng token của bạn:

```python
BOT_TOKEN = "1234567890:ABCdefGHIjklMNOpqrsTUVwxyz"
```

### Bước 5: Cấu hình Affiliate Links

Tìm các dòng:

```python
BINANCE_REF = "https://accounts.binance.com/register?ref=YOUR_REF"
OKX_REF = "https://www.okx.com/join/YOUR_REF"
BYBIT_REF = "https://www.bybit.com/invite?ref=YOUR_REF"
```

Thay bằng link affiliate của bạn:

**Cách lấy link affiliate:**

1. **Binance:**
   - Đăng ký: https://www.binance.com
   - Vào: Account → Referral
   - Copy link referral

2. **OKX:**
   - Đăng ký: https://www.okx.com
   - Vào: Rewards Hub → Referral
   - Copy link

3. **Bybit:**
   - Đăng ký: https://www.bybit.com
   - Vào: Rewards Hub → Affiliate
   - Copy link

### Bước 6: Chạy Bot

```bash
python bot.py
```

Nếu thành công, bạn sẽ thấy:
```
INFO - Bot started!
```

## 📱 Sử Dụng Bot

Mở Telegram, tìm bot của bạn, gõ:

- `/start` - Bắt đầu
- `/price bitcoin` - Xem giá Bitcoin
- `/alert btc 50000` - Đặt cảnh báo BTC = $50k
- `/myalerts` - Xem alerts của bạn
- `/trending` - Top coins trending
- `/airdrop` - Airdrop mới
- `/help` - Hướng dẫn

## 💰 Kiếm Tiền Với Bot

### 1. Affiliate Marketing (Chính)

Bot tích hợp sẵn affiliate links trong mọi reply. Mỗi khi user:
- Click link → Đăng ký sàn → Bạn nhận hoa hồng
- Hoa hồng: 20-50% phí giao dịch của họ **MÃI MÃI**

**Thu nhập tiềm năng:**
- 100 users → 10 đăng ký → 5 active traders
- 5 traders × 100k/tháng = **500k/tháng**
- 1000 users = **5-10 triệu/tháng**

### 2. Premium Features

Thêm tính năng trả phí:
- Portfolio tracking: 99k/tháng
- Trading signals: 199k/tháng
- Priority alerts: 49k/tháng

### 3. Sponsored Content

Dự án crypto trả để bạn post thông báo:
- 1 post = 1-5 triệu
- 1000 users = 5-10 post/tháng

### 4. Ads

Với 1000+ users, bạn có thể bán ads trong bot.

## 🔧 Tùy Chỉnh

### Thêm coin mới

Trong hàm `price_command`, thêm vào `coin_map`:

```python
coin_map = {
    'btc': 'bitcoin',
    'eth': 'ethereum',
    'shib': 'shiba-inu',  # Thêm coin mới
}
```

### Thay đổi thời gian check alerts

Trong hàm `main()`, tìm dòng:

```python
job_queue.run_repeating(check_alerts, interval=300, first=10)
```

Đổi `interval=300` (5 phút) thành số giây bạn muốn.

### Thêm airdrop mới

Trong hàm `airdrop_command`, thêm vào list `airdrops`:

```python
{
    'name': 'Tên Airdrop',
    'reward': 'Phần thưởng',
    'tasks': 'Nhiệm vụ',
    'link': 'Link tham gia'
}
```

## 🚀 Deploy Lên Server (Chạy 24/7)

### Option 1: Railway.app (Miễn phí)

1. Tạo tài khoản: https://railway.app
2. New Project → Deploy from GitHub
3. Connect repo
4. Thêm biến môi trường: `BOT_TOKEN`
5. Deploy!

### Option 2: Render.com (Miễn phí)

1. Tạo tài khoản: https://render.com
2. New → Background Worker
3. Connect repo
4. Start Command: `python bot.py`
5. Deploy!

### Option 3: VPS

```bash
# Cài tmux
sudo apt install tmux

# Chạy bot trong tmux
tmux new -s cryptobot
python bot.py

# Detach: Ctrl+B, sau đó D
# Attach lại: tmux attach -t cryptobot
```

## 📊 Theo Dõi Hiệu Quả

Bot tự động lưu users vào database `crypto_bot.db`.

Xem số lượng users:

```bash
sqlite3 crypto_bot.db "SELECT COUNT(*) FROM users"
```

Xem số alerts:

```bash
sqlite3 crypto_bot.db "SELECT COUNT(*) FROM alerts"
```

## 🛠️ Troubleshooting

### Lỗi: "Invalid token"
→ Kiểm tra lại BOT_TOKEN

### Lỗi: "Module not found"
→ Chạy: `pip install -r requirements.txt`

### Bot không reply
→ Kiểm tra internet, kiểm tra token

### Alerts không hoạt động
→ Kiểm tra background task đang chạy

## 📞 Support

- Telegram: @BotBanHangVN
- Email: support@botbanhang.vn
- Website: botbanhang.vn

## 📄 License

Bạn đã mua source code này, có toàn quyền sử dụng, chỉnh sửa, và kiếm tiền.

**KHÔNG được:**
- Bán lại source code này
- Chia sẻ miễn phí cho người khác

## 🎉 Chúc Bạn Kiếm Tiền Thành Công!

Nếu có câu hỏi, liên hệ support nhé! 💪
