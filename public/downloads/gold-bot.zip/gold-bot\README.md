# 💰 Gold Price Bot - Telegram

Bot Telegram cập nhật giá vàng SJC, PNJ, DOJI real-time.

## Cài Đặt

```bash
pip install -r requirements.txt
```

Cấu hình `BOT_TOKEN` trong `bot.py`, sau đó:

```bash
python bot.py
```

## Sử Dụng

- `/giavang` - Xem giá vàng
- `/alert sjc 76000000` - Đặt cảnh báo
- `/help` - Hướng dẫn

## Kiếm Tiền

- Affiliate tiệm vàng online
- Affiliate bảo hiểm vàng
- Lead generation

Chi tiết: Xem README trong crypto-bot (cấu trúc tương tự)
