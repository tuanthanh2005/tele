# 📊 Stock Bot - Telegram

Bot Telegram theo dõi giá cổ phiếu Việt Nam real-time.

## Cài Đặt

```bash
pip install -r requirements.txt
```

Cấu hình `BOT_TOKEN` trong `bot.py`, sau đó:

```bash
python bot.py
```

## Sử Dụng

- `/cp VNM` - Xem giá cổ phiếu
- `/vnindex` - Xem VN-Index
- `/alert VNM 100000` - Đặt cảnh báo
- `/help` - Hướng dẫn

## Kiếm Tiền

- Affiliate sàn chứng khoán
- Affiliate khóa học đầu tư
- Lead generation

Chi tiết: Xem README trong crypto-bot (cấu trúc tương tự)
