<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" fill="none" <?php echo e($attributes); ?>>
  <g clip-path="url(#clip0_14550_6155)">
    <path d="M8.75 8.25012L6 11.0001L3.25 8.25012" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M8.75 3.75012L6 1.00012L3.25 3.75012" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>
  </g>
  <defs>
    <clipPath id="clip0_14550_6155">
      <rect width="12" height="12" fill="white" style="fill:white;fill-opacity:1;"/>
    </clipPath>
  </defs>
</svg>
<?php /**PATH D:\telegram-python\Traffic-Tool\traffic-python-laravel\vendor\laravel\framework\src\Illuminate\Foundation\Providers/../resources/exceptions/renderer/components/icons/chevrons-up-down.blade.php ENDPATH**/ ?>